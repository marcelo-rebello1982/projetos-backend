package com.polovyi.ivan.tutorials;


import org.junit.jupiter.api.Test;

public class StreamsTest {

    @Test
    public void test() {

    }

}
