
<p align="center">
  <img width="460" height="300" src="https://miro.medium.com/v2/resize:fit:1400/format:webp/1*9pYSBOXuQx0fMI6KIMxVMQ.jpeg">
</p>

<h1 align="center"><a href="https://medium.com/gitconnected/java-stream-api-mastering-collectors-bf504551024a">Java Stream API: Mastering Collectors
</a></h1>
